package com.bfhl.webhookdemo;

import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Service
public class WebhookService {

    private final RestTemplate restTemplate = new RestTemplate();

    public void callGenerateWebhookAPI() {
        String url = "https://bfhldevapigw.healthrx.co.in/hiring/generateWebhook/JAVA";

        // Create request body
        Map<String, String> requestBody = new HashMap<>();
        requestBody.put("name", "Gaurav Pradip Shelke"); // Replace with your name
        requestBody.put("regNo", "1032233061"); // Replace with your regNo
        requestBody.put("email", "gaurav.shelke@mitwpu.edu.in"); // Replace with your email

        // Set headers
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        // Create HttpEntity with body and headers
        HttpEntity<Map<String, String>> entity = new HttpEntity<>(requestBody, headers);

        try {
            // Send POST request
            ResponseEntity<Map> response = restTemplate.exchange(
                    url,
                    HttpMethod.POST,
                    entity,
                    Map.class
            );

            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                String webhook = response.getBody().get("webhook").toString();
                String accessToken = response.getBody().get("accessToken").toString();

                System.out.println("✅ Webhook URL: " + webhook);
                System.out.println("🔑 Access Token: " + accessToken);

                // You can store these in variables or pass them to the next step (Step 3)

            } else {
                System.out.println(" Error: Unexpected response from API");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void submitFinalQuery(String webhookUrl, String accessToken) {
        RestTemplate restTemplate = new RestTemplate();

        // Your final SQL query
        String finalQuery = "SELECT p.AMOUNT AS SALARY, CONCAT(e.FIRST_NAME, ' ', e.LAST_NAME) AS NAME, FLOOR(DATEDIFF(CURDATE(), e.DOB) / 365) AS AGE, d.DEPARTMENT_NAME FROM PAYMENTS p JOIN EMPLOYEE e ON p.EMP_ID = e.EMP_ID JOIN DEPARTMENT d ON e.DEPARTMENT = d.DEPARTMENT_ID WHERE DAY(p.PAYMENT_TIME) != 1 ORDER BY p.AMOUNT DESC LIMIT 1;";

        // Set headers with JWT token
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(accessToken); // Important!

        // Request body with final SQL query
        Map<String, String> body = new HashMap<>();
        body.put("finalQuery", finalQuery);

        HttpEntity<Map<String, String>> requestEntity = new HttpEntity<>(body, headers);

        try {
            ResponseEntity<String> response = restTemplate.postForEntity(
                    webhookUrl,
                    requestEntity,
                    String.class
            );

            if (response.getStatusCode() == HttpStatus.OK) {
                System.out.println("✅ Query submitted successfully!");
                System.out.println("Response: " + response.getBody());
            } else {
                System.out.println("Failed to submit query. Status: " + response.getStatusCode());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
