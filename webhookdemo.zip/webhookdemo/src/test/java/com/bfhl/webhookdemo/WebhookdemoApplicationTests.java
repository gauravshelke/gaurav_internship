package com.bfhl.webhookdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebhookdemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
